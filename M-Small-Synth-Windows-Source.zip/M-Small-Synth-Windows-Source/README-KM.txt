# M-Small Synth — Windows Standalone Source

នេះជាគម្រោង Source Code សម្រាប់បង្កើតកម្មវិធី **M-Small Synth.exe** ដែលបើកដាច់ដោយឡែកលើ Windows 10/11។ វាមិនមែនជា `.exe` ដែលបាន Build រួចទេ។

## មុខងារដែលមាន
- សំឡេង synth មូលដ្ឋាន និង audio output
- Waveform: Sine, Saw, Square, Triangle
- Frequency, Volume និង Detune controls
- On-screen chromatic keyboard
- GUI ពណ៌ខ្មៅ/ខៀវបែប synth

## អ្វីដែលត្រូវដំឡើងលើ Windows
1. **Visual Studio 2022 Community** — ជ្រើស workload **Desktop development with C++**។
2. **CMake** (កំណែ 3.22 ឬថ្មីជាងនេះ)។
3. Internet connection នៅពេល Build លើកដំបូង ព្រោះ CMake នឹងទាញយក JUCE 8.0.6 ពី GitHub។

Official links:
- Visual Studio: https://visualstudio.microsoft.com/vs/community/
- CMake: https://cmake.org/download/
- JUCE documentation: https://juce.com/learn/tutorials/

## របៀប Build ដើម្បីទទួលបាន EXE
1. Extract ZIP នេះទៅ Folder ធម្មតា ឧទាហរណ៍ `C:\M-Small-Synth`.
2. បើក Folder ហើយចុចពីរដងលើ `build-windows.bat`។
3. រង់ចាំ CMake ទាញយក JUCE និង Compile។ លើកដំបូងអាចចំណាយពេលច្រើននាទី។
4. បើ Build ជោគជ័យ ឯកសារ EXE នឹងស្ថិតនៅ៖
   `build\MSmallSynth_artefacts\Release\M-Small Synth.exe`
   (ទីតាំងអាចខុសបន្តិចតាមកំណែ JUCE/CMake; បើរកមិនឃើញ ស្វែងរក `M-Small Synth.exe` នៅក្នុង `build`។)

## ប្រសិនបើមានបញ្ហា
- ពិនិត្យថាបានដំឡើង Visual Studio workload **Desktop development with C++**។
- ត្រូវមានអ៊ីនធឺណិតពេល Build លើកដំបូង។
- ប្រសិនបើ `cmake` មិនត្រូវបានស្គាល់ សូមដំឡើង CMake ហើយបិទ/បើក Command Prompt ឡើងវិញ។
- នេះជា prototype synth ដំបូង មិនទាន់ជំនួស synth អាជីពពេញលេញបានទេ។
