@echo off
setlocal
cd /d "%~dp0"

where cmake >nul 2>nul
if errorlevel 1 (
  echo ERROR: CMake not found. Install CMake and restart this script.
  pause
  exit /b 1
)

echo [1/2] Configuring M-Small Synth...
cmake -S . -B build
if errorlevel 1 (
  echo.
  echo Configure failed. Check that Visual Studio C++ tools are installed and internet is available.
  pause
  exit /b 1
)

echo.
echo [2/2] Building Release EXE...
cmake --build build --config Release
if errorlevel 1 (
  echo.
  echo Build failed. Please read the error messages above.
  pause
  exit /b 1
)

echo.
echo Build complete. Searching for M-Small Synth.exe...
where /r build "M-Small Synth.exe"
echo.
echo If the EXE path was printed above, open it to run M-Small Synth.
pause
