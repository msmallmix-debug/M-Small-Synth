#include <juce_audio_utils/juce_audio_utils.h>
#include <atomic>
#include <cmath>

class MSmallSynthApp final : public juce::JUCEApplication
{
public:
    const juce::String getApplicationName() override { return "M-Small Synth"; }
    const juce::String getApplicationVersion() override { return "1.0.0"; }
    bool moreThanOneInstanceAllowed() override { return true; }

    void initialise(const juce::String&) override
    {
        mainWindow = std::make_unique<MainWindow>(getApplicationName());
    }

    void shutdown() override { mainWindow = nullptr; }
    void systemRequestedQuit() override { quit(); }

private:
    class MainWindow final : public juce::DocumentWindow
    {
    public:
        explicit MainWindow(juce::String name)
            : DocumentWindow(name,
                             juce::Colour::fromRGB(13, 17, 31),
                             DocumentWindow::allButtons)
        {
            setUsingNativeTitleBar(true);
            setContentOwned(new SynthComponent(), true);
            centreWithSize(900, 590);
            setResizable(true, true);
            setResizeLimits(760, 520, 1400, 900);
            setVisible(true);
        }

        void closeButtonPressed() override { juce::JUCEApplication::getInstance()->systemRequestedQuit(); }
    };

    class SynthComponent final : public juce::AudioAppComponent,
                                 private juce::Slider::Listener,
                                 private juce::ComboBox::Listener,
                                 private juce::Button::Listener
    {
    public:
        SynthComponent()
        {
            setSize(900, 590);
            setAudioChannels(0, 2);

            addAndMakeVisible(frequencySlider);
            styleSlider(frequencySlider, "FREQUENCY");
            frequencySlider.setRange(55.0, 880.0, 1.0);
            frequencySlider.setValue(220.0);
            frequencySlider.addListener(this);

            addAndMakeVisible(volumeSlider);
            styleSlider(volumeSlider, "VOLUME");
            volumeSlider.setRange(0.0, 0.8, 0.01);
            volumeSlider.setValue(0.25);
            volumeSlider.addListener(this);

            addAndMakeVisible(detuneSlider);
            styleSlider(detuneSlider, "DETUNE");
            detuneSlider.setRange(0.0, 30.0, 0.1);
            detuneSlider.setValue(5.0);
            detuneSlider.addListener(this);

            addAndMakeVisible(waveformBox);
            waveformBox.addItem("SINE", 1);
            waveformBox.addItem("SAW", 2);
            waveformBox.addItem("SQUARE", 3);
            waveformBox.addItem("TRIANGLE", 4);
            waveformBox.setSelectedId(1);
            waveformBox.addListener(this);
            waveformBox.setColour(juce::ComboBox::backgroundColourId, panel);
            waveformBox.setColour(juce::ComboBox::textColourId, juce::Colours::white);
            waveformBox.setColour(juce::ComboBox::outlineColourId, cyan);

            addAndMakeVisible(statusLabel);
            statusLabel.setText("AUDIO READY  •  SELECT A NOTE", juce::dontSendNotification);
            statusLabel.setColour(juce::Label::textColourId, cyan);
            statusLabel.setFont(juce::Font(13.0f, juce::Font::bold));
            statusLabel.setJustificationType(juce::Justification::centredLeft);

            const char* names[] = { "C", "C#", "D", "D#", "E", "F", "F#", "G", "G#", "A", "A#", "B" };
            for (int i = 0; i < 12; ++i)
            {
                auto* key = new juce::TextButton(names[i]);
                key->setComponentID(juce::String(i));
                key->addListener(this);
                key->setClickingTogglesState(false);
                key->setColour(juce::TextButton::buttonColourId,
                               (names[i][1] == '#') ? juce::Colour::fromRGB(36, 42, 62)
                                                    : juce::Colour::fromRGB(228, 235, 246));
                key->setColour(juce::TextButton::textColourOffId,
                               (names[i][1] == '#') ? juce::Colours::white
                                                    : juce::Colour::fromRGB(20, 27, 43));
                addAndMakeVisible(key);
                keys.add(key);
            }
            frequency.store(220.0);
            gain.store(0.25);
            detune.store(5.0);
        }

        ~SynthComponent() override
        {
            frequencySlider.setLookAndFeel(nullptr);
            volumeSlider.setLookAndFeel(nullptr);
            detuneSlider.setLookAndFeel(nullptr);
            shutdownAudio();
        }

        void prepareToPlay(int, double sampleRate) override
        {
            currentSampleRate = sampleRate > 0.0 ? sampleRate : 44100.0;
            phase = 0.0;
            phase2 = 0.0;
        }

        void getNextAudioBlock(const juce::AudioSourceChannelInfo& info) override
        {
            auto* left = info.buffer->getWritePointer(0, info.startSample);
            auto* right = info.buffer->getNumChannels() > 1
                        ? info.buffer->getWritePointer(1, info.startSample) : nullptr;
            const auto freq = frequency.load();
            const auto vol = gain.load();
            const auto det = detune.load();
            const auto shape = waveform.load();
            const auto inc1 = juce::MathConstants<double>::twoPi * freq / currentSampleRate;
            const auto inc2 = juce::MathConstants<double>::twoPi * (freq * std::pow(2.0, det / 1200.0)) / currentSampleRate;

            for (int i = 0; i < info.numSamples; ++i)
            {
                const float a = oscillator(phase, shape);
                const float b = oscillator(phase2, shape);
                float sample = (a + b) * 0.5f * static_cast<float>(vol);
                sample = juce::jlimit(-0.95f, 0.95f, sample);
                left[i] = sample;
                if (right != nullptr) right[i] = sample;
                phase += inc1;
                phase2 += inc2;
                if (phase >= juce::MathConstants<double>::twoPi) phase -= juce::MathConstants<double>::twoPi;
                if (phase2 >= juce::MathConstants<double>::twoPi) phase2 -= juce::MathConstants<double>::twoPi;
            }
        }

        void releaseResources() override {}

        void paint(juce::Graphics& g) override
        {
            g.fillAll(juce::Colour::fromRGB(10, 13, 25));
            auto bounds = getLocalBounds().toFloat();
            g.setColour(juce::Colour::fromRGB(21, 27, 46));
            g.fillRoundedRectangle(bounds.reduced(14.0f), 18.0f);

            g.setColour(cyan);
            g.fillRoundedRectangle(30.0f, 28.0f, 5.0f, 48.0f, 2.0f);
            g.setFont(juce::Font(29.0f, juce::Font::bold));
            g.drawText("M-SMALL SYNTH", 48, 24, 400, 36, juce::Justification::centredLeft);
            g.setColour(juce::Colour::fromRGB(157, 171, 197));
            g.setFont(juce::Font(12.0f, juce::Font::plain));
            g.drawText("VIRTUAL INSTRUMENT  /  STANDALONE EDITION", 49, 60, 450, 20, juce::Justification::centredLeft);

            g.setColour(juce::Colour::fromRGB(34, 43, 68));
            g.fillRoundedRectangle(30.0f, 103.0f, static_cast<float>(getWidth() - 60), 230.0f, 13.0f);
            g.setColour(cyan);
            g.setFont(juce::Font(13.0f, juce::Font::bold));
            g.drawText("SOUND ENGINE", 50, 117, 200, 22, juce::Justification::centredLeft);

            g.setColour(juce::Colour::fromRGB(34, 43, 68));
            g.fillRoundedRectangle(30.0f, 351.0f, static_cast<float>(getWidth() - 60), 190.0f, 13.0f);
            g.setColour(cyan);
            g.drawText("PLAY NOTES", 50, 364, 200, 22, juce::Justification::centredLeft);

            // Decorative waveform line
            juce::Path wave;
            const float x0 = 530.0f, y0 = 160.0f, w = static_cast<float>(getWidth()) - 590.0f;
            wave.startNewSubPath(x0, y0);
            for (int i = 0; i <= 180; ++i)
            {
                const float x = x0 + w * static_cast<float>(i) / 180.0f;
                const float y = y0 + 23.0f * std::sin(static_cast<float>(i) * 0.18f);
                wave.lineTo(x, y);
            }
            g.setColour(cyan.withAlpha(0.75f));
            g.strokePath(wave, juce::PathStrokeType(2.0f));
        }

        void resized() override
        {
            auto area = getLocalBounds().reduced(48, 0);
            frequencySlider.setBounds(48, 166, 135, 145);
            volumeSlider.setBounds(204, 166, 135, 145);
            detuneSlider.setBounds(360, 166, 135, 145);
            waveformBox.setBounds(535, 211, juce::jmax(160, getWidth() - 600), 36);
            statusLabel.setBounds(48, getHeight() - 60, 420, 24);

            const int keyCount = keys.size();
            const int gap = 7;
            const int totalWidth = getWidth() - 110;
            const int keyWidth = (totalWidth - (keyCount - 1) * gap) / keyCount;
            for (int i = 0; i < keyCount; ++i)
                keys[i]->setBounds(50 + i * (keyWidth + gap), 407, keyWidth, 92);
        }

    private:
        static constexpr auto cyan = juce::Colour(0xff27e0d0);
        static constexpr auto panel = juce::Colour(0xff202944);

        juce::Slider frequencySlider, volumeSlider, detuneSlider;
        juce::ComboBox waveformBox;
        juce::Label statusLabel;
        juce::OwnedArray<juce::TextButton> keys;
        std::atomic<double> frequency { 220.0 };
        std::atomic<double> gain { 0.25 };
        std::atomic<double> detune { 5.0 };
        std::atomic<int> waveform { 0 };
        double currentSampleRate = 44100.0;
        double phase = 0.0, phase2 = 0.0;

        void styleSlider(juce::Slider& s, const juce::String& name)
        {
            s.setSliderStyle(juce::Slider::RotaryHorizontalVerticalDrag);
            s.setTextBoxStyle(juce::Slider::TextBoxBelow, false, 85, 22);
            s.setName(name);
            s.setColour(juce::Slider::rotarySliderFillColourId, cyan);
            s.setColour(juce::Slider::rotarySliderOutlineColourId, juce::Colour::fromRGB(53, 65, 91));
            s.setColour(juce::Slider::thumbColourId, juce::Colours::white);
            s.setColour(juce::Slider::textBoxTextColourId, juce::Colours::white);
            s.setColour(juce::Slider::textBoxBackgroundColourId, panel);
            s.setColour(juce::Slider::textBoxOutlineColourId, juce::Colours::transparentBlack);
            s.setLookAndFeel(&lookAndFeel);
        }

        struct SynthLookAndFeel final : juce::LookAndFeel_V4
        {
            SynthLookAndFeel()
            {
                setColour(juce::Slider::textBoxTextColourId, juce::Colours::white);
                setColour(juce::Slider::textBoxBackgroundColourId, panelColour);
            }
            static constexpr auto panelColour = juce::Colour(0xff202944);
        } lookAndFeel;

        static float oscillator(double p, int shape)
        {
            const double norm = p / juce::MathConstants<double>::twoPi;
            switch (shape)
            {
                case 1: return static_cast<float>(2.0 * norm - 1.0); // saw
                case 2: return p < juce::MathConstants<double>::pi ? 1.0f : -1.0f; // square
                case 3: return static_cast<float>(1.0 - 4.0 * std::abs(norm - 0.5)); // triangle
                default: return static_cast<float>(std::sin(p));
            }
        }

        void sliderValueChanged(juce::Slider* slider) override
        {
            if (slider == &frequencySlider) frequency.store(slider->getValue());
            if (slider == &volumeSlider) gain.store(slider->getValue());
            if (slider == &detuneSlider) detune.store(slider->getValue());
        }

        void comboBoxChanged(juce::ComboBox* box) override
        {
            if (box == &waveformBox) waveform.store(box->getSelectedId() - 1);
        }

        void buttonClicked(juce::Button* button) override
        {
            const int note = button->getComponentID().getIntValue();
            const double midiNote = 60.0 + note;
            const double hz = 440.0 * std::pow(2.0, (midiNote - 69.0) / 12.0);
            frequencySlider.setValue(hz, juce::sendNotificationSync);
            statusLabel.setText("PLAYING NOTE  •  " + button->getButtonText(), juce::dontSendNotification);
        }
    };

    std::unique_ptr<MainWindow> mainWindow;
};

START_JUCE_APPLICATION(MSmallSynthApp)
